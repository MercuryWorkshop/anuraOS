zipMods = [
['hldm.zip','HLDM (62M)', 64668974],
['uplink.zip', 'Uplink (44M)', 45496413],
['uplink-nohc.zip', 'Uplink without HC (29M)', 30567963],
['hc.zip', 'Hazard Course (22M)', 22766605],
['dayone.zip', 'Day One (75M)', 78804629]
];

pkgMods = [
['hldm.js','HLDM (82M)'],
['uplink.js', 'Uplink (61M)']
];

