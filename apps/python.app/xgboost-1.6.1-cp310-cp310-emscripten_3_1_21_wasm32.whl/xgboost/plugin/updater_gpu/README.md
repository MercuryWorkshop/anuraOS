# XGBoost GPU algorithms

GPU algorithms are no longer a plugin and are included in official releases. [See documentation for more details](https://xgboost.readthedocs.io/en/latest/gpu/).
