import sys
from fontTools.varLib import main


if __name__ == '__main__':
	sys.exit(main())
